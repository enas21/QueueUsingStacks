#include "Queue.h"
#include <iostream>
#include <stack>
#include <cstdlib>
using namespace std;

Queue::Queue()
{
    //len=-1;
}
void Queue::EnQueue(int e)
{
    s1.push(e);
    len++;
}

void Queue::DeQueue()
{
    do
    {
        int s=s1.top();
        s2.push(s);
        s1.pop();
    }
    while(s1.empty()==false);
    s2.pop();
    len--;
    do
    {
        int t=s2.top();
        s1.push(t);
        s2.pop();
    }
    while(s2.empty()==false);
}
void Queue::print()
{
    int arr[len];
    int c=0;
    do
    {
        int s=s1.top();
        s2.push(s);
        s1.pop();
        //cout<<s<<" ";
        arr[c]=s;
        c++;
    }
    while(s1.empty()==false);
    do
    {
        int t=s2.top();
        s1.push(t);
        s2.pop();
    }
    while(s2.empty()==false);
    for(int i=len;i>=0;i--)
        cout<<arr[i]<<" ";

}
Queue::~Queue()
{
    //dtor
}
