#include <iostream>
#include "Queue.h"
using namespace std;

int main()
{
    Queue q;
    q.EnQueue(8);
    q.EnQueue(7);
    q.EnQueue(15);
    q.EnQueue(22);
    q.EnQueue(3);
    cout<<"The out put is :"<<endl;
    cout<<"After Enqueue 8"<<endl;
    cout<<"After Enqueue 7"<<endl;
    cout<<"After Enqueue 15"<<endl;
    cout<<"After Enqueue 22"<<endl;
    cout<<"After Enqueue 3"<<endl<<endl;
    q.print();
    q.DeQueue();
    cout<<endl<<endl<<"After First Dequeue"<<endl;
    q.print();
    q.DeQueue();
    cout<<endl<<endl<<"After Second Dequeue"<<endl;
    q.print();
    q.DeQueue();
    cout<<endl<<endl<<"After Third Dequeue"<<endl;
    q.print();


}
