#ifndef QUEUE_H
#define QUEUE_H
#include <stack>
#include <iostream>

using namespace std;

const int s=100;
class Queue
{
    public:
        Queue();
        void EnQueue(int e);
        void DeQueue();
        void print();
        virtual ~Queue();

    protected:

    private:
        //int arr1[s];
        int len;
        stack<int> s1;
        stack<int> s2;
        stack<int> temp;
};

#endif // QUEUE_H
